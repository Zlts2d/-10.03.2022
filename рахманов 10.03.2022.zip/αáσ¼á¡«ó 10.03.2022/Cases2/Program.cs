﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasesLibrary;

namespace Cases2
{
    class Program
    {
        static void Main(string[] args)
        {
            schoolJour sj = new schoolJour();

            Console.WriteLine("----------------------");
            Console.WriteLine("Задание №1");
            List<Student> stl = new List<Student>()
            {
                new Student ("818", 2018, "фамилия имя отчество" ),
                new Student ("818", 2019, "иванов пёрт романович" )
            };

            Mark mrtest = new Mark();
            List<Mark> mrl = sj.GetMarks(new DateTime(2021, 07, 26), stl);
            for(int i = 0; i < mrl.Count; i++)
            {
                Console.WriteLine($"{mrl[i].date} ---- {mrl[i].Estimation}");
            }

            Console.WriteLine("----------------------");
            Console.WriteLine("Задание №2");

            string[] mr = { "2", "2", "3", "4", "2", "5", "б", "п", "5", "2", "2", "3", "3", "2", "у", "б", "п", "б" };
            Console.WriteLine(sj.MinAVG(mr));

            Console.WriteLine("----------------------");
            Console.WriteLine("Задание №3");

            foreach (int i in sj.GetCountTruancy(mrl))
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("----------------------");
            Console.WriteLine("Задание №4");

            foreach (int i in sj.GetCountDisease(mrl))
            {
                Console.WriteLine(i);
            }


            Console.WriteLine("----------------------");
            Console.WriteLine("Задание №5");
            Student s1 = new Student("113124", 2018, "Иванов Николай Романович");
            Console.WriteLine(sj.GetStudNumber(s1));

            
            Console.ReadKey();
        }
    }
}
