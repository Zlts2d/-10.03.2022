﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasesLibrary
{
    public class schoolJour
    {
        Random r = new Random();
        public string GetStudNumber(Student st)
        {
            string res = "";
            res += st.years + ".";
            res += st.group + ".";

            string prom = ""; int count = 0;
            string newFIO = st.FIO;
            prom += newFIO[0];
            for (int i = 0; i < 2; i++)
            {
                foreach (char c in newFIO)
                {
                    if (c == ' ')
                    {
                        newFIO = newFIO.Remove(0, count + 1);
                        prom += newFIO[0];
                        break;
                    }
                    count++;
                }
                count = 0;
            }

            res += prom;

            return res;
        }
        public List<Mark> GetMarks(DateTime dtNow, List<Student> st)
        {
            string[] est = { "2", "3", "4", "5", "п", "б", "у", "" };


            List<Mark> marksList = new List<Mark>();

            for (int i = 0; i < st.Count; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Mark mark = new Mark()
                    {
                        date = dtNow.AddDays(j),
                        Estimation = est[r.Next(0, 8)]
                    };
                    marksList.Add(mark);
                }
            }

            return marksList;
        }

        public double MinAVG(string[] marks)
        {
            double count = 0; int countMarks = 0;
            for (int i = 0; i < marks.Length; i++)
            {
                if (int.TryParse(marks[i], out int number))
                {
                    count += int.Parse(marks[i]);
                    countMarks++;
                }
            }

            double res = Math.Round(count / countMarks, 3);
            if (res.ToString().Contains(",") && res.ToString().Length > 4)
            {
                res = double.Parse(res.ToString().Remove(4));
            }

            return res;

        }

        public int[] GetCountTruancy(List<Mark> marks)
        {
            Dictionary<string, int> res = new Dictionary<string, int>()
            {
                {"01", 0},
                {"02", 0},
                {"03", 0},
                {"04", 0},
                {"05", 0},
                {"06", 0},
                {"07", 0},
                {"08", 0},
                {"09", 0},
                {"10", 0},
                {"11", 0},
                {"12", 0},
            };

            foreach (var c in marks)
            {
                if (c.Estimation == "п")
                {
                    res[c.date.ToString().Remove(0, 3).Remove(2)] += 1;
                }
            }

            List<int> resMass = new List<int>();
            foreach (int c in res.Values)
            {
                if (c > 0)
                {
                    resMass.Add(c);
                }

            }
            return resMass.ToArray();
        }

        public int[] GetCountDisease(List<Mark> marks)
        {
            Dictionary<string, int> res = new Dictionary<string, int>()
            {
                {"01", 0},
                {"02", 0},
                {"03", 0},
                {"04", 0},
                {"05", 0},
                {"06", 0},
                {"07", 0},
                {"08", 0},
                {"09", 0},
                {"10", 0},
                {"11", 0},
                {"12", 0},
            };

            foreach (var c in marks)
            {
                if (c.Estimation == "б")
                {
                   
                    res[c.date.ToString().Remove(0, 3).Remove(2)] += 1;
                }
            }

            List<int> resMass = new List<int>();
            foreach (int c in res.Values)
            {
                if (c > 0)
                {
                    resMass.Add(c);
                }

            }
            return resMass.ToArray();
        }
    }

     public class Student
    {
        public string group;
        public int years;
        public string FIO;

        public Student(string gr, int ye, string fio)
        {
            this.group = gr;
            this.years = ye;
            this.FIO = fio;
        }

        public Student()
        {

        }
    }

    public class Mark
    {
        public DateTime date;
        public string Estimation;

        public Mark(DateTime dt, string Est)
        {
            this.date = dt;
            this.Estimation = Est;
        }
        public Mark()
        {

        }
    }
}
